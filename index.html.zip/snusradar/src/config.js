// 🔧 REPLACE THIS WITH YOUR FIREBASE CONFIG
// Go to: console.firebase.google.com → Your project → Project settings → Your apps → SDK setup
// Copy the firebaseConfig object and paste it here

export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// 🗺️ REPLACE WITH YOUR GOOGLE MAPS API KEY
// Go to: console.cloud.google.com → APIs & Services → Credentials → Create API Key
// Enable: Maps JavaScript API
export const GOOGLE_MAPS_API_KEY = "YOUR_GOOGLE_MAPS_API_KEY";
