# 📡 SnusRadar

Real-time snus tracker — see your friends on a live Google Maps, check who has snus, and ping them when you need some.

---

## 🚀 Setup Guide (step by step)

### Step 1 — Firebase project

1. Go to **https://console.firebase.google.com**
2. Click **Add project** → give it a name (e.g. `snusradar`)
3. Disable Google Analytics (not needed) → **Create project**

#### Enable Authentication
1. In the left sidebar → **Authentication** → **Get started**
2. Click **Email/Password** → toggle **Enable** → Save

#### Enable Firestore
1. In the left sidebar → **Firestore Database** → **Create database**
2. Choose **Start in production mode** → pick your region (e.g. `europe-west1`) → Enable

#### Set Firestore Rules
1. In Firestore → **Rules** tab
2. Replace the content with what's in `firestore.rules` in this project
3. Click **Publish**

#### Get your Firebase config
1. In Firebase → **Project settings** (gear icon) → **General**
2. Scroll to **Your apps** → click **</>** (Web)
3. Register the app (name it anything) → copy the `firebaseConfig` object

---

### Step 2 — Google Maps API key

1. Go to **https://console.cloud.google.com**
2. Select your project (or create one)
3. Go to **APIs & Services** → **Library**
4. Search for **Maps JavaScript API** → Enable it
5. Go to **APIs & Services** → **Credentials** → **Create credentials** → **API key**
6. Copy the key (optionally restrict it to your domain for security)

---

### Step 3 — Configure the app

Open `src/config.js` and fill in your keys:

```js
export const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "snusradar-xxxx.firebaseapp.com",
  projectId: "snusradar-xxxx",
  storageBucket: "snusradar-xxxx.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef"
};

export const GOOGLE_MAPS_API_KEY = "AIzaSy...";
```

---

### Step 4 — Run locally

```bash
# Install dependencies
npm install

# Start dev server
npm run dev

# Open http://localhost:3000
```

---

### Step 5 — Deploy (free with Firebase Hosting)

```bash
# Install Firebase CLI
npm install -g firebase-tools

# Login
firebase login

# Initialize hosting (run once)
firebase init hosting
# → Select your Firebase project
# → Public directory: dist
# → Single-page app: yes
# → Don't overwrite index.html

# Build the app
npm run build

# Deploy!
firebase deploy
```

Your app will be live at `https://YOUR_PROJECT_ID.web.app`

---

## 📲 Sharing with friends

Once deployed, each user:
1. Creates an account with email + password
2. Sets up their profile (name, snus brands, availability)
3. Adds friends by searching their email — OR copies their invite link from the **Add friend** dialog and sends it

---

## ✨ Features

- **Live map** — friends shown as pins on Google Maps with real GPS
- **Real-time status** — availability updates instantly (Got plenty / Running low / Empty)
- **Snus brands** — each person lists what they have
- **Stock meter** — 0–100% stock level with visual bar
- **Ping** — send a "want snus?" notification to a friend
- **Friend search** — add friends by email address
- **Invite links** — share a link that pre-selects you as a friend to add

---

## 🗂️ Project structure

```
snusradar/
├── index.html          # Entry point
├── src/
│   ├── config.js       # 🔧 Your API keys go here
│   ├── firebase.js     # Firebase service layer
│   ├── main.js         # App logic
│   └── style.css       # Styles
├── firestore.rules     # Copy to Firebase Console
├── vite.config.js      # Build config
└── package.json
```
